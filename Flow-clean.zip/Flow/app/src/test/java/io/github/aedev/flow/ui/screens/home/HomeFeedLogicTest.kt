/*
 * Copyright (C) 2025-2026 Flow | A-EDev
 *
 * This file is part of Flow (https://github.com/Flow-Tube/Flow).
 */

package io.github.aedev.flow.ui.screens.home

import com.google.common.truth.Truth.assertThat
import io.github.aedev.flow.data.local.VideoHistoryEntry
import io.github.aedev.flow.data.model.Video
import io.github.aedev.flow.data.recommendation.FlowPersona
import io.github.aedev.flow.data.recommendation.GraphSeedInput
import io.github.aedev.flow.data.recommendation.GraphSeedSource
import io.github.aedev.flow.data.recommendation.UserBrain
import org.junit.Test

/** I-10: behavioral coverage for the home-feed consumer logic (R-2 seeds, I-1 impressions). */
class HomeFeedLogicTest {
    private fun entry(
        id: String,
        pos: Long,
        dur: Long,
        ts: Long,
        isShort: Boolean = false,
    ) = VideoHistoryEntry(
        videoId = id,
        position = pos,
        duration = dur,
        timestamp = ts,
        title = "t-$id",
        thumbnailUrl = "",
        isShort = isShort,
    )

    @Test
    fun `history graph seeds keep non-shorts newest first with progress metadata`() {
        val history =
            listOf(
                entry("a", 90, 100, ts = 1), // 90% ✓
                entry("b", 50, 100, ts = 2), // 50% ✗ below threshold
                entry("c", 80, 100, ts = 3, isShort = true), // short ✗
                entry("d", 100, 100, ts = 4), // 100% ✓ newest
            )
        val seeds = graphSeedInputsFromHistory(history)
        assertThat(seeds.map { it.id }).containsExactly("d", "b", "a").inOrder()
        assertThat(seeds.first { it.id == "a" }.engagementWeight).isWithin(1e-6).of(0.9)
        assertThat(seeds.first { it.id == "a" }.percentWatched).isWithin(1e-6).of(90.0)
    }

    @Test
    fun `history graph seeds are capped at max`() {
        val history = (1..20).map { entry("v$it", 100, 100, ts = it.toLong()) }
        assertThat(graphSeedInputsFromHistory(history, max = 4)).hasSize(4)
    }

    @Test
    fun `impression filter drops non-video keys like shelves and loaders`() {
        val visible = listOf("v1", "shorts_shelf", "v2", "loading_indicator")
        val known = setOf("v1", "v2", "v3")
        assertThat(feedImpressionIds(visible, known)).containsExactly("v1", "v2").inOrder()
    }

    private fun v(
        title: String,
        duration: Int,
    ) = Video(
        id = title,
        title = title,
        channelName = "C",
        channelId = "c",
        thumbnailUrl = "",
        duration = duration,
        viewCount = 1000,
        uploadDate = "1 day ago",
    )

    private val defaultTaste =
        FeedTasteProfile(
            comfortDurationSec = DURATION_COMFORT_DEFAULT_SEC,
            affinityTopics = emptySet(),
        )

    @Test
    fun `format markers demote exploration content only for users with no matching interest`() {
        val compilation = v("Amazing Cream Dessert Korean Bakery Compilation", 600)
        // No baking interest: marker penalty applies.
        assertThat(feedFitPenalty(compilation, defaultTaste)).isGreaterThan(0.0)
        // Baking enthusiast: the same video is a good fit, no penalty.
        val baker = defaultTaste.copy(affinityTopics = setOf("baking", "bakery", "dessert"))
        assertThat(feedFitPenalty(compilation, baker)).isEqualTo(0.0)
    }

    @Test
    fun `long-form is penalised by comfort but never for long-form personas`() {
        val essay = v("Three hour deep dive documentary", 11_000)
        assertThat(feedFitPenalty(essay, defaultTaste)).isGreaterThan(0.0)
        // Deep-diver / scholar tolerate any length: comfort cap is 0 ⇒ no duration penalty.
        val deepDiver =
            feedTasteProfile(
                UserBrain(totalInteractions = 200),
                FlowPersona.DEEP_DIVER,
            )
        assertThat(feedFitPenalty(essay, deepDiver)).isEqualTo(0.0)
    }

    @Test
    fun `demoteByFit pushes poor-fit items below well-fit ones without dropping any`() {
        val ranked =
            listOf(
                v("3 Hour Baking Compilation Marathon", 11_000), // marker + far over comfort
                v("Kotlin coroutines explained", 900), // clean
            )
        val out = demoteByFit(ranked, defaultTaste)
        assertThat(out.map { it.id })
            .containsExactly("Kotlin coroutines explained", "3 Hour Baking Compilation Marathon")
            .inOrder()
        assertThat(out).hasSize(ranked.size) // nothing dropped
    }

    @Test
    fun `well-fit content keeps its engine order`() {
        val ranked = listOf(v("Kotlin coroutines explained", 900), v("Python walkthrough", 1_200))
        assertThat(demoteByFit(ranked, defaultTaste).map { it.id })
            .containsExactly("Kotlin coroutines explained", "Python walkthrough")
            .inOrder()
    }

    private fun vc(
        id: String,
        channelId: String,
    ) = Video(
        id = id,
        title = id,
        channelName = channelId,
        channelId = channelId,
        thumbnailUrl = "",
        duration = 600,
        viewCount = 1,
        uploadDate = "1 day ago",
    )

    private fun gc(
        video: Video,
        seedId: String,
        seedScore: Double,
        graphRank: Int = 0,
        seedResultCount: Int = 12,
        hitCount: Int = 1,
    ) = GraphCandidate(
        video = video,
        seedId = seedId,
        seedScore = seedScore,
        graphRank = graphRank,
        seedCluster = "cluster-$seedId",
        seedResultCount = seedResultCount,
        hitCount = hitCount,
    )

    private fun adjacentSameChannel(videos: List<Video>) =
        videos.zipWithNext().count { (a, b) -> a.channelId.isNotBlank() && a.channelId == b.channelId }

    @Test
    fun `a page runs a couple from the other lanes in turn, then one or two from followed channels (#907)`() {
        val related = (1..6).map { vc("r$it", "R$it") }
        val discovery = (1..6).map { vc("d$it", "D$it") }
        val subs = (1..4).map { vc("s$it", "S$it") }
        val page = listOf(vc("fresh1", "F1"), vc("fresh2", "F2")) + subs + related + discovery
        val source = (related.map { it.id to FeedSource.RELATED } + discovery.map { it.id to FeedSource.DISCOVERY }).toMap()
        val followed = { v: Video -> v.channelId.startsWith("S") || v.channelId.startsWith("F") }

        val laid = rhythmBySource(page, followed, { source[it.id] }, keepTop = 2)
        val kinds = laid.joinToString("") { if (followed(it)) "S" else it.id.take(1) }

        assertThat(kinds).isEqualTo("SSrrSddSrrSddSrrdd")
        assertThat(laid.filter(followed).map { it.id }).isEqualTo(listOf("fresh1", "fresh2") + (1..4).map { "s$it" })
        assertThat(laid.filter { it.id.startsWith("r") }.map { it.id }).isEqualTo(related.map { it.id })
    }

    @Test
    fun `followed-channel videos the rhythm has no room for wait for later pages, unless the page runs short`() {
        val page = (1..10).map { vc("s$it", "S$it") } + (1..4).map { vc("o$it", "O$it") }
        val followed = { v: Video -> v.channelId.startsWith("S") }

        val deferred = rhythmBySource(page, followed, deferExtra = true, minSize = 8)
        val kept = rhythmBySource(page, followed)

        assertThat(deferred).hasSize(8)
        assertThat(deferred.joinToString("") { if (followed(it)) "S" else "o" }).isEqualTo("SSooSSoo")
        assertThat(kept.map { it.id }).containsExactlyElementsIn(page.map { it.id })
    }

    @Test
    fun `spaceByChannel separates clustered same-channel items without dropping any`() {
        val clustered =
            listOf(
                vc("a1", "A"),
                vc("a2", "A"),
                vc("a3", "A"),
                vc("b1", "B"),
                vc("c1", "C"),
            )
        val spaced = spaceByChannel(clustered)
        assertThat(spaced.map { it.id }).containsExactlyElementsIn(clustered.map { it.id })
        assertThat(adjacentSameChannel(spaced)).isEqualTo(0)
    }

    @Test
    fun `a wide gap keeps a channel's two videos ten cards apart when the page allows it`() {
        val page = listOf(vc("a1", "A"), vc("a2", "A")) + (1..12).map { vc("o$it", "O$it") }

        val spaced = spaceByChannel(page, gap = 10)

        assertThat(spaced.indexOfFirst { it.id == "a2" } - spaced.indexOfFirst { it.id == "a1" }).isAtLeast(11)
    }

    @Test
    fun `spaceByChannel honours the seeded tail to avoid cross-page repeats`() {
        // Prior page ended on channel A; a page that starts with A must not lead with it.
        val page = listOf(vc("a1", "A"), vc("b1", "B"))
        val spaced = spaceByChannel(page, seedRecent = listOf("A"))
        assertThat(spaced.first().channelId).isEqualTo("B")
    }

    @Test
    fun `one search takes no more than its even share before the others are placed`() {
        val ranked = (1..6).map { vc("h$it", "H$it") } + (1..3).map { vc("p$it", "P$it") }
        val searchOf = ranked.associate { it.id to if (it.id.startsWith("h")) "anime horror" else "pixel" }

        val spread = spreadAcrossSearches(ranked, searchOf::get, limit = 6)

        assertThat(spread.map { it.id }).containsExactly("h1", "h2", "h3", "p1", "p2", "p3").inOrder()
    }

    @Test
    fun `a single search keeps its rank order`() {
        val ranked = (1..4).map { vc("h$it", "H$it") }

        assertThat(spreadAcrossSearches(ranked, { "anime horror" }, limit = 3).map { it.id }).containsExactly("h1", "h2", "h3").inOrder()
    }

    @Test
    fun `spaceByChannel ignores blank channel ids`() {
        val related = listOf(vc("r1", ""), vc("r2", ""), vc("r3", ""))
        assertThat(spaceByChannel(related).map { it.id }).containsExactly("r1", "r2", "r3").inOrder()
    }

    @Test
    fun `a mature viewer's neighbours share the memory lane's remainder`() {
        val quotas = homeFeedQuotas(40, subCount = 12, totalInteractions = 200, hasNeighbours = true)

        assertThat(quotas[FeedSource.NEIGHBOURS]).isEqualTo(2)
        assertThat(quotas[FeedSource.CHANNEL_MEMORY]).isEqualTo(2)
        assertThat(quotas.values.sum()).isEqualTo(40)
    }

    @Test
    fun `home feed quotas adapt to no subscription maturing and mature profiles`() {
        assertThat(homeFeedQuotas(40, subCount = 0, totalInteractions = 200))
            .containsExactly(
                FeedSource.SUBS,
                0,
                FeedSource.RELATED,
                14,
                FeedSource.DISCOVERY,
                18,
                FeedSource.CHANNEL_MEMORY,
                8,
                FeedSource.NEIGHBOURS,
                0,
            )

        assertThat(homeFeedQuotas(40, subCount = 12, totalInteractions = 20))
            .containsExactly(
                FeedSource.SUBS,
                14,
                FeedSource.RELATED,
                12,
                FeedSource.DISCOVERY,
                10,
                FeedSource.CHANNEL_MEMORY,
                4,
                FeedSource.NEIGHBOURS,
                0,
            )

        assertThat(homeFeedQuotas(40, subCount = 12, totalInteractions = 200))
            .containsExactly(
                FeedSource.SUBS,
                16,
                FeedSource.RELATED,
                10,
                FeedSource.DISCOVERY,
                10,
                FeedSource.CHANNEL_MEMORY,
                4,
                FeedSource.NEIGHBOURS,
                0,
            )
    }

    @Test
    fun `blendFeedSources reports source distribution`() {
        val result =
            blendFeedSources(
                lanes =
                    mapOf(
                        FeedSource.SUBS to listOf(vc("s1", "S")),
                        FeedSource.RELATED to listOf(vc("r1", "R")),
                        FeedSource.DISCOVERY to listOf(vc("d1", "D")),
                        FeedSource.CHANNEL_MEMORY to listOf(vc("v1", "V")),
                    ),
                quotas =
                    mapOf(
                        FeedSource.SUBS to 1,
                        FeedSource.RELATED to 1,
                        FeedSource.DISCOVERY to 1,
                        FeedSource.CHANNEL_MEMORY to 1,
                    ),
                targetSize = 4,
            )

        assertThat(result.videos.map { it.id }).containsExactly("s1", "r1", "d1", "v1").inOrder()
        assertThat(result.sourceCounts)
            .containsExactly(
                FeedSource.SUBS,
                1,
                FeedSource.RELATED,
                1,
                FeedSource.DISCOVERY,
                1,
                FeedSource.CHANNEL_MEMORY,
                1,
                FeedSource.NEIGHBOURS,
                0,
            )
    }

    @Test
    fun `blendFeedSources relaxes scarce quota in related discovery subs order`() {
        val result =
            blendFeedSources(
                lanes =
                    mapOf(
                        FeedSource.SUBS to listOf(vc("s1", "S"), vc("s2", "S")),
                        FeedSource.RELATED to listOf(vc("r1", "R1"), vc("r2", "R2")),
                        FeedSource.DISCOVERY to listOf(vc("d1", "D1"), vc("d2", "D2")),
                        FeedSource.CHANNEL_MEMORY to listOf(vc("v1", "V1"), vc("v2", "V2")),
                    ),
                quotas = FeedSource.entries.associateWith { 0 },
                targetSize = 3,
            )

        assertThat(result.items.map { it.source })
            .containsExactly(FeedSource.RELATED, FeedSource.RELATED, FeedSource.DISCOVERY)
            .inOrder()
        assertThat(result.videos.map { it.id }).containsExactly("r1", "r2", "d1").inOrder()
    }

    @Test
    fun `a channel gets one video per page, and a second only at the end when the lanes run short`() {
        val full =
            blendFeedSources(
                lanes =
                    mapOf(
                        FeedSource.SUBS to listOf(vc("a1", "A"), vc("a2", "A"), vc("b1", "B"), vc("b2", "B")),
                        FeedSource.RELATED to listOf(vc("c1", "C"), vc("c2", "C"), vc("e1", "E")),
                        FeedSource.DISCOVERY to listOf(vc("f1", "F"), vc("g1", "G")),
                    ),
                quotas = mapOf(FeedSource.SUBS to 4, FeedSource.RELATED to 3, FeedSource.DISCOVERY to 2),
                targetSize = 6,
            )
        val short =
            blendFeedSources(
                lanes = mapOf(FeedSource.SUBS to listOf(vc("a1", "A"), vc("a2", "A"), vc("b1", "B"))),
                quotas = mapOf(FeedSource.SUBS to 3),
                targetSize = 3,
            )

        assertThat(full.videos.map { it.channelId }.distinct()).hasSize(6)
        assertThat(short.videos.map { it.id }).containsExactly("a1", "b1", "a2").inOrder()
    }

    @Test
    fun `the channel memory lane never takes more than its quota`() {
        val result =
            blendFeedSources(
                lanes =
                    mapOf(
                        FeedSource.RELATED to listOf(vc("r1", "R1")),
                        FeedSource.CHANNEL_MEMORY to (1..10).map { vc("m$it", "M$it") },
                    ),
                quotas = mapOf(FeedSource.RELATED to 5, FeedSource.CHANNEL_MEMORY to 2),
                targetSize = 10,
            )

        assertThat(result.sourceCounts[FeedSource.CHANNEL_MEMORY]).isEqualTo(2)
        assertThat(result.videos.map { it.id }).containsExactly("r1", "m1", "m2")
    }

    @Test
    fun `a channel memory channel appears once per page whatever lane brings it`() {
        val result =
            blendFeedSources(
                lanes =
                    mapOf(
                        FeedSource.RELATED to listOf(vc("r1", "M1"), vc("r2", "M1"), vc("r3", "R")),
                        FeedSource.CHANNEL_MEMORY to listOf(vc("m1", "M1")),
                    ),
                quotas = mapOf(FeedSource.RELATED to 3, FeedSource.CHANNEL_MEMORY to 1),
                targetSize = 10,
                singleChannels = setOf("M1"),
            )

        assertThat(result.videos.count { it.channelId == "M1" }).isEqualTo(1)
    }

    @Test
    fun `a rejected head does not stop the refill while the lane has usable videos`() {
        val usedIds = mutableSetOf("r1", "r2")
        val result =
            blendFeedSources(
                lanes = mapOf(FeedSource.RELATED to listOf(vc("r1", "A"), vc("r2", "B"), vc("r3", "C"), vc("r4", "D"))),
                quotas = FeedSource.entries.associateWith { 0 },
                targetSize = 2,
                usedVideoIds = usedIds,
            )

        assertThat(result.videos.map { it.id }).containsExactly("r3", "r4").inOrder()
    }

    @Test
    fun `mergeGraphCandidates counts multi-seed convergence and keeps strongest metadata`() {
        val weak = gc(vc("shared", "A"), seedId = "s1", seedScore = 0.7, graphRank = 5)
        val strong = gc(vc("shared", "B"), seedId = "s2", seedScore = 1.2, graphRank = 2)

        val merged = mergeGraphCandidates(listOf(weak, strong)).single()

        assertThat(merged.hitCount).isEqualTo(2)
        assertThat(merged.seedId).isEqualTo("s2")
        assertThat(merged.seedScore).isWithin(1e-6).of(1.2)
        assertThat(merged.graphRank).isEqualTo(2)
    }

    @Test
    fun `graph boost lets multi-seed candidate beat an adjacent weak graph candidate`() {
        val ranked = (0 until 20).map { vc("v$it", "C$it") }.toMutableList()
        val oneOff = vc("one_off", "one")
        val multiSeed = vc("multi_seed", "multi")
        ranked[10] = oneOff
        ranked[11] = multiSeed

        val boosted =
            applyGraphBoost(
                ranked,
                mapOf(
                    oneOff.id to gc(oneOff, seedId = "s1", seedScore = 0.4, graphRank = 0),
                    multiSeed.id to gc(multiSeed, seedId = "s2", seedScore = 1.2, graphRank = 0, hitCount = 2),
                ),
            )

        assertThat(boosted.indexOf(multiSeed)).isLessThan(boosted.indexOf(oneOff))
    }

    @Test
    fun `fit demotion still wins after graph boost`() {
        val clean = v("Kotlin coroutines explained", 900)
        val poorFit = v("3 Hour Baking Compilation Marathon", 11_000)
        val ranked = (0 until 20).map { vc("v$it", "C$it") }.toMutableList()
        ranked[10] = clean
        ranked[11] = poorFit

        val boosted =
            applyGraphBoost(
                ranked,
                mapOf(poorFit.id to gc(poorFit, seedId = "s1", seedScore = 1.2, graphRank = 0, hitCount = 2)),
            )
        val demoted = demoteByFit(boosted, defaultTaste)

        assertThat(demoted.indexOf(clean)).isLessThan(demoted.indexOf(poorFit))
    }

    @Test
    fun `addUniquePageVideos fills page without duplicates or channel overflow`() {
        val page = mutableListOf<Video>()
        val channelCounts = mutableMapOf<String, Int>()
        val usedIds = mutableSetOf("existing")
        val candidates =
            listOf(
                vc("existing", "A"),
                vc("a1", "A"),
                vc("a2", "A"),
                vc("a3", "A"),
                vc("b1", "B"),
            )

        val added =
            addUniquePageVideos(
                candidates = candidates,
                targetList = page,
                channelCounts = channelCounts,
                usedVideoIds = usedIds,
                targetSize = 3,
                maxPerChannel = 2,
            )

        assertThat(added).isEqualTo(3)
        assertThat(page.map { it.id }).containsExactly("a1", "a2", "b1").inOrder()
    }

    @Test
    fun `sourceEntropy is normalized across active sources`() {
        assertThat(sourceEntropy(mapOf(FeedSource.RELATED to 4))).isEqualTo(0.0)
        assertThat(sourceEntropy(FeedSource.entries.associateWith { 1 })).isWithin(1e-6).of(1.0)
    }

    @Test
    fun `related lane metrics summarize graph quality signals`() {
        val seeds =
            listOf(
                graphSeed("h1", GraphSeedSource.WATCH_HISTORY),
                graphSeed("l1", GraphSeedSource.LIKED),
                graphSeed("p1", GraphSeedSource.PLAYLIST),
            )
        val r1 = vc("r1", "R")
        val r2 = vc("r2", "R")
        val metrics =
            buildRelatedLaneMetrics(
                seedInputs = seeds,
                seedIds = listOf("h1", "l1"),
                fetchedPerSeed = mapOf("h1" to 3, "l1" to 0),
                mergedRelatedCandidates = listOf(gc(r1, "h1", 1.2), gc(r2, "h1", 1.1)),
                filteredRelatedCandidates = listOf(gc(r1, "h1", 1.2)),
                selectedSourceCounts =
                    mapOf(
                        FeedSource.RELATED to 2,
                        FeedSource.DISCOVERY to 1,
                        FeedSource.SUBS to 1,
                    ),
                finalFeedCount = 4,
                finalRelatedVideoIds = setOf("r1", "r2"),
                brain =
                    UserBrain(
                        watchHistoryMap = mapOf("r1" to 0.8f),
                        suppressedVideoIds = mapOf("r2" to 100L),
                    ),
            )

        assertThat(metrics.seedCandidatesAvailable).isEqualTo(3)
        assertThat(metrics.seedsSelected).isEqualTo(2)
        assertThat(metrics.seedSourceCounts)
            .containsExactly(GraphSeedSource.WATCH_HISTORY, 1, GraphSeedSource.LIKED, 1)
        assertThat(metrics.nextEmptyRate).isWithin(1e-6).of(0.5)
        assertThat(metrics.relatedDedupeRate).isWithin(1e-6).of(1.0 - (2.0 / 3.0))
        assertThat(metrics.relatedCandidatesSurvivingFilters).isEqualTo(1)
        assertThat(metrics.finalRelatedShare).isWithin(1e-6).of(0.5)
        assertThat(metrics.relatedWatchThroughProxy).isWithin(1e-6).of(0.5)
        assertThat(metrics.relatedSkipDislikeProxy).isWithin(1e-6).of(0.5)
        assertThat(metrics.sourceEntropy).isGreaterThan(0.0)
    }

    private fun graphSeed(
        id: String,
        source: GraphSeedSource,
        timestamp: Long = 100L,
    ) = GraphSeedInput(
        id = id,
        title = "title-$id",
        channelId = "",
        source = source,
        engagementWeight = 1.0,
        timestamp = timestamp,
        durationSec = 600,
        percentWatched = 100.0,
    )

    @Test
    fun `saved interest seed inputs preserve source order before engine selection`() {
        val sources =
            SavedSeedSources(
                history = listOf(graphSeed("h_latest", GraphSeedSource.WATCH_HISTORY)),
                liked = listOf(graphSeed("l1", GraphSeedSource.LIKED)),
                playlists = listOf(graphSeed("p1", GraphSeedSource.PLAYLIST)),
            )
        val seeds = savedInterestSeedInputs(sources, cooldown = emptySet())
        assertThat(seeds.map { it.id }).containsExactly("h_latest", "l1", "p1").inOrder()
    }

    @Test
    fun `saved interest seed inputs pull from history liked and playlists within bounds`() {
        val sources =
            SavedSeedSources(
                history = (1..10).map { graphSeed("h$it", GraphSeedSource.WATCH_HISTORY) },
                liked = (1..10).map { graphSeed("l$it", GraphSeedSource.LIKED) },
                playlists = (1..10).map { graphSeed("p$it", GraphSeedSource.PLAYLIST) },
            )
        val seeds = savedInterestSeedInputs(sources, cooldown = emptySet(), maxPerSource = 2)
        val ids = seeds.map { it.id }
        assertThat(seeds.size).isEqualTo(6)
        assertThat(ids.any { it.startsWith("h") }).isTrue()
        assertThat(ids.any { it.startsWith("l") }).isTrue()
        assertThat(ids.any { it.startsWith("p") }).isTrue()
    }

    @Test
    fun `saved interest seed inputs exclude ids on cooldown`() {
        val sources =
            SavedSeedSources(
                history =
                    listOf(
                        graphSeed("h_latest", GraphSeedSource.WATCH_HISTORY),
                        graphSeed("h2", GraphSeedSource.WATCH_HISTORY),
                    ),
                liked = listOf(graphSeed("l1", GraphSeedSource.LIKED)),
                playlists = listOf(graphSeed("p1", GraphSeedSource.PLAYLIST)),
            )
        val cooldown = setOf("h_latest", "l1", "p1")
        val seeds = savedInterestSeedInputs(sources, cooldown = cooldown)
        assertThat(seeds.map { it.id }).containsNoneIn(cooldown)
        assertThat(seeds.map { it.id }).contains("h2")
    }

    @Test
    fun `saved interest seed inputs return empty when nothing is saved`() {
        val empty = SavedSeedSources(emptyList(), emptyList(), emptyList())
        assertThat(savedInterestSeedInputs(empty, cooldown = emptySet())).isEmpty()
    }

    @Test
    fun `the shorts shelf keeps rank order but moves recently shown reels to the back`() {
        val shelf =
            listOf("a", "b", "c", "d").map { id ->
                Video(
                    id = id,
                    title = id,
                    channelName = "",
                    channelId = "",
                    thumbnailUrl = "",
                    duration = 30,
                    viewCount = 0,
                    uploadDate = "",
                )
            }

        val rotated = shelf.recentlyShownLast { it == "a" || it == "c" }

        assertThat(rotated.map { it.id }).containsExactly("b", "d", "a", "c").inOrder()
    }

    @Test
    fun `what a related lane put on screen never seeds the next related lane`() {
        val feed =
            listOf("discovery", "related").map { id ->
                Video(
                    id = id,
                    title = id,
                    channelName = "",
                    channelId = "",
                    thumbnailUrl = "",
                    duration = 600,
                    viewCount = 0,
                    uploadDate = "",
                )
            }

        val seeds = feedSeedInputs(feed, now = 1L, max = 10, relatedPickIds = setOf("related"))

        assertThat(seeds.map { it.id }).containsExactly("discovery")
    }
}
